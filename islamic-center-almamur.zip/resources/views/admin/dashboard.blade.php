@extends('admin.layouts.master')

@section('title', "Dashboard Administrator | Masjid Jami Al-Mamur")

